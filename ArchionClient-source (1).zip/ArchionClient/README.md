# Archion Client — Fabric 1.21.11 source

Client-side Fabric mod with a dark purple click GUI (Right Shift) and anarchy-server modules.
Intended for anarchy servers (e.g. 2b2t-style) where this is allowed. Using combat modules on servers that forbid them can get you banned.

## Modules
| Tab | Module | What it does |
|---|---|---|
| Combat | Sword PvP | Attacks the nearest player in reach at full attack cooldown; optional auto-switch to sword and aim |
| Combat | Mace PvP | Optionally jumps + throws a wind charge to launch, then switches to the mace and smashes on the way down |
| Combat | Crystal PvP | Places crystals on obsidian/bedrock and breaks them, using a damage estimate with self-damage and min-health limits |
| Exploration | Base Finder | Scans chunks your client already has for player-built signs (chests, hoppers, shulkers, redstone parts, glass...), reports in chat and logs to `waypoints.txt` |
| Misc | Macros | Key-bound chat/command macros from `config/archion/macros.txt` |

## Config (`config/archion/config.properties`)
Created on first launch with every default; edit and restart. Examples: `sword.range`, `mace.minFallDistance`,
`crystal.maxSelfDamage`, `crystal.minHealthAfter`, `basefinder.threshold`, `friends=name1,name2` (never targeted).
Module on/off state is saved here too.

## Macros (`config/archion/macros.txt`)
```
g | /sethome base
j | /kill ;; wait 40 ;; /home base
```
`;;` separates actions, `wait N` pauses N ticks, a leading `/` sends a command. Use "Reload macros" in the Misc tab after editing.

## Notes
- Base Finder only uses chunk data already sent to you, so it finds bases within your render distance. Villages, ancient cities and bastions can cause false positives; raise `basefinder.threshold` if noisy.
- HUD toggles are still placeholders (no rendering yet).

## Build
JDK 21 + Gradle 9.x: `gradle build`, then put `build/libs/archion-client-0.1.0.jar` in `mods` with Fabric API.
