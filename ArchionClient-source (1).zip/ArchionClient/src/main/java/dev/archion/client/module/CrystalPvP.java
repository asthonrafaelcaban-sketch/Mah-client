package dev.archion.client.module;

import dev.archion.client.Config;
import dev.archion.client.PlayerUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Crystal aura: places crystals on obsidian/bedrock near the target and breaks them, with self-damage limits. */
public final class CrystalPvP extends Module {
    private final double targetRange = Config.getDouble("crystal.targetRange", 10.0);
    private final double placeRange = Config.getDouble("crystal.placeRange", 4.5);
    private final double breakRange = Config.getDouble("crystal.breakRange", 4.5);
    private final double minTargetDmg = Config.getDouble("crystal.minTargetDamage", 4.0);
    private final double maxSelfDmg = Config.getDouble("crystal.maxSelfDamage", 6.0);
    private final double minHealth = Config.getDouble("crystal.minHealthAfter", 6.0);
    private final int placeDelay = Math.max(1, Config.getInt("crystal.placeDelayTicks", 2));
    private final int breakDelay = Math.max(1, Config.getInt("crystal.breakDelayTicks", 1));
    private final boolean autoSwitch = Config.getBool("crystal.autoSwitch", true);

    private int tick;

    public CrystalPvP() {
        super("Crystal PvP", Category.COMBAT, "Auto place/break crystals with damage checks");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        tick++;
        ClientPlayerEntity p = mc.player;
        PlayerEntity target = PlayerUtil.nearestPlayer(mc, targetRange, false);
        if (target == null) return;
        double selfHp = p.getHealth() + p.getAbsorptionAmount();

        if (tick % breakDelay == 0 && breakCrystal(mc, p, target, selfHp)) return;
        if (tick % placeDelay == 0) placeCrystal(mc, p, target, selfHp);
    }

    private boolean breakCrystal(MinecraftClient mc, ClientPlayerEntity p, PlayerEntity target, double selfHp) {
        ClientWorld w = mc.world;
        List<EndCrystalEntity> crystals = w.getEntitiesByClass(EndCrystalEntity.class,
                p.getBoundingBox().expand(breakRange), c -> true);
        EndCrystalEntity best = null;
        double bestDmg = 0;
        for (EndCrystalEntity c : crystals) {
            if (p.distanceTo(c) > breakRange) continue;
            Vec3d pos = new Vec3d(c.getX(), c.getY(), c.getZ());
            double self = PlayerUtil.crystalDamage(pos, p);
            double dmg = PlayerUtil.crystalDamage(pos, target);
            if (dmg < minTargetDmg || self > maxSelfDmg || selfHp - self < minHealth) continue;
            if (dmg > bestDmg) { best = c; bestDmg = dmg; }
        }
        if (best == null) return false;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private void placeCrystal(MinecraftClient mc, ClientPlayerEntity p, PlayerEntity target, double selfHp) {
        boolean offhand = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        int slot = -1;
        if (!offhand) {
            if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) slot = PlayerUtil.selectedSlot(p);
            else if (autoSwitch) slot = PlayerUtil.findHotbar(p, s -> s.isOf(Items.END_CRYSTAL));
            if (slot < 0) return;
        }

        ClientWorld w = mc.world;
        Vec3d eye = PlayerUtil.eye(p);
        BlockPos base = BlockPos.ofFloored(eye);
        int r = (int) Math.ceil(placeRange);
        BlockPos bestPos = null;
        double bestScore = Double.NEGATIVE_INFINITY;

        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = base.add(x, y, z);
            if (eye.squaredDistanceTo(Vec3d.ofCenter(pos)) > placeRange * placeRange) continue;
            BlockState s = w.getBlockState(pos);
            if (!s.isOf(Blocks.OBSIDIAN) && !s.isOf(Blocks.BEDROCK)) continue;
            if (!w.isAir(pos.up()) || !w.isAir(pos.up(2))) continue;

            Vec3d crystal = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
            double dmg = PlayerUtil.crystalDamage(crystal, target);
            double self = PlayerUtil.crystalDamage(crystal, p);
            if (dmg < minTargetDmg || self > maxSelfDmg || selfHp - self < minHealth) continue;

            Box space = new Box(pos.getX(), pos.getY() + 1, pos.getZ(), pos.getX() + 1, pos.getY() + 3, pos.getZ() + 1);
            if (!w.getOtherEntities(null, space).isEmpty()) continue;

            double score = dmg - self * 0.5;
            if (score > bestScore) { bestScore = score; bestPos = pos; }
        }
        if (bestPos == null) return;

        if (!offhand) PlayerUtil.selectSlot(p, slot);
        Hand hand = offhand ? Hand.OFF_HAND : Hand.MAIN_HAND;
        BlockHitResult hit = new BlockHitResult(
                new Vec3d(bestPos.getX() + 0.5, bestPos.getY() + 1.0, bestPos.getZ() + 0.5),
                Direction.UP, bestPos, false);
        mc.interactionManager.interactBlock(p, hand, hit);
        p.swingHand(hand);
    }
}
