package dev.archion.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny properties-backed config at config/archion/config.properties. Defaults are written on first run. */
public final class Config {
    private static final Properties PROPS = new Properties();
    private static Path dir;

    private Config() {}

    public static Path dir() {
        if (dir == null) dir = FabricLoader.getInstance().getConfigDir().resolve("archion");
        return dir;
    }

    public static void load() {
        Path f = dir().resolve("config.properties");
        if (!Files.exists(f)) return;
        try (var in = Files.newInputStream(f)) {
            PROPS.load(in);
        } catch (IOException ignored) {}
    }

    public static void save() {
        try {
            Files.createDirectories(dir());
            try (var out = Files.newOutputStream(dir().resolve("config.properties"))) {
                PROPS.store(out, "Archion Client settings (restart the game after editing)");
            }
        } catch (IOException ignored) {}
    }

    public static String getString(String key, String def) {
        String v = PROPS.getProperty(key);
        if (v == null) {
            PROPS.setProperty(key, def);
            return def;
        }
        return v;
    }

    public static double getDouble(String key, double def) {
        try {
            return Double.parseDouble(getString(key, String.valueOf(def)).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public static int getInt(String key, int def) {
        return (int) Math.round(getDouble(key, def));
    }

    public static boolean getBool(String key, boolean def) {
        return Boolean.parseBoolean(getString(key, String.valueOf(def)).trim());
    }

    public static void setBool(String key, boolean value) {
        PROPS.setProperty(key, String.valueOf(value));
        save();
    }
}
