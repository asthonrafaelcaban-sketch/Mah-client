package dev.archion.client.module;

import dev.archion.client.Config;
import dev.archion.client.PlayerUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Mace smash helper. Optionally jumps and throws a wind charge at your feet to launch,
 * then switches to the mace and smashes the nearest player on the way down.
 */
public final class MacePvP extends Module {
    private enum Phase { IDLE, JUMPING, LAUNCHED }

    private final double reach = Config.getDouble("mace.reach", 3.0);
    private final double minFall = Config.getDouble("mace.minFallDistance", 1.5);
    private final double launchRange = Config.getDouble("mace.launchRange", 7.0);
    private final double searchRange = Config.getDouble("mace.searchRange", 12.0);
    private final boolean windBoost = Config.getBool("mace.windChargeLaunch", true);
    private final boolean autoSwitch = Config.getBool("mace.autoSwitch", true);
    private final boolean rotate = Config.getBool("mace.rotate", true);

    private Phase phase = Phase.IDLE;
    private int timer, cooldown;

    public MacePvP() {
        super("Mace PvP", Category.COMBAT, "Wind-charge launch and mace smash");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.jumpKey.setPressed(false);
        phase = Phase.IDLE;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cooldown > 0) cooldown--;

        if (phase == Phase.JUMPING) {
            if (!p.isOnGround()) {
                mc.options.jumpKey.setPressed(false);
                if (throwWindCharge(mc, p)) { phase = Phase.LAUNCHED; timer = 0; }
                else phase = Phase.IDLE;
            } else if (++timer > 3) {
                mc.options.jumpKey.setPressed(false);
                phase = Phase.IDLE;
                cooldown = 20;
            }
            return;
        }

        PlayerEntity target = PlayerUtil.nearestPlayer(mc, searchRange, false);

        if (phase == Phase.LAUNCHED && p.isOnGround() && ++timer > 3) {
            phase = Phase.IDLE;
            cooldown = 30;
        }
        if (target == null) return;

        double dist = p.distanceTo(target);

        // Smash while falling
        if (p.fallDistance > minFall && p.getVelocity().y < 0 && dist <= reach) {
            if (autoSwitch && !p.getMainHandStack().isOf(Items.MACE)) {
                PlayerUtil.selectSlot(p, PlayerUtil.findHotbar(p, s -> s.isOf(Items.MACE)));
            }
            if (!p.getMainHandStack().isOf(Items.MACE)) return;
            if (rotate) PlayerUtil.lookAt(p, PlayerUtil.body(target));
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
            return;
        }

        // Start a launch
        if (windBoost && phase == Phase.IDLE && cooldown == 0 && p.isOnGround() && dist <= launchRange
                && PlayerUtil.findHotbar(p, s -> s.isOf(Items.MACE)) >= 0
                && PlayerUtil.findHotbar(p, s -> s.isOf(Items.WIND_CHARGE)) >= 0) {
            mc.options.jumpKey.setPressed(true);
            phase = Phase.JUMPING;
            timer = 0;
        }
    }

    private boolean throwWindCharge(MinecraftClient mc, ClientPlayerEntity p) {
        int slot = PlayerUtil.findHotbar(p, s -> s.isOf(Items.WIND_CHARGE));
        if (slot < 0) return false;
        float oldPitch = p.getPitch();
        PlayerUtil.selectSlot(p, slot);
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.setPitch(oldPitch);
        return true;
    }
}
