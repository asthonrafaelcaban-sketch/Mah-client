package dev.archion.client.module;

import dev.archion.client.Config;
import dev.archion.client.PlayerUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;

/** Sword aura: attacks the nearest player in reach at full attack cooldown. */
public final class SwordPvP extends Module {
    private final double range = Config.getDouble("sword.range", 3.0);
    private final double cooldown = Config.getDouble("sword.cooldown", 0.92);
    private final boolean rotate = Config.getBool("sword.rotate", true);
    private final boolean autoSwitch = Config.getBool("sword.autoSwitch", true);
    private final boolean needSight = Config.getBool("sword.requireLineOfSight", true);

    public SwordPvP() {
        super("Sword PvP", Category.COMBAT, "Auto-attacks nearest player with a sword");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        PlayerEntity target = PlayerUtil.nearestPlayer(mc, range, needSight);
        if (target == null) return;

        if (autoSwitch && !p.getMainHandStack().isIn(ItemTags.SWORDS)) {
            PlayerUtil.selectSlot(p, PlayerUtil.findHotbar(p, s -> s.isIn(ItemTags.SWORDS)));
        }
        if (!p.getMainHandStack().isIn(ItemTags.SWORDS)) return;

        if (rotate) PlayerUtil.lookAt(p, PlayerUtil.body(target));
        if (p.getAttackCooldownProgress(0.5f) < cooldown) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }
}
