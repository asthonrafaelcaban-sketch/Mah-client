package dev.archion.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.function.Predicate;

/** Shared helpers. Version-sensitive API calls are kept here so they are easy to fix in one place. */
public final class PlayerUtil {
    private static final Set<String> FRIENDS = new HashSet<>();

    static {
        for (String n : Config.getString("friends", "").split(",")) {
            if (!n.isBlank()) FRIENDS.add(n.trim().toLowerCase(Locale.ROOT));
        }
    }

    private PlayerUtil() {}

    public static boolean isFriend(PlayerEntity p) {
        return FRIENDS.contains(p.getName().getString().toLowerCase(Locale.ROOT));
    }

    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range, boolean needSight) {
        ClientPlayerEntity me = mc.player;
        PlayerEntity best = null;
        double bestD = range * range;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == me || !o.isAlive() || o.isSpectator() || isFriend(o)) continue;
            double d = me.squaredDistanceTo(o);
            if (d > bestD) continue;
            if (needSight && !me.canSee(o)) continue;
            best = o;
            bestD = d;
        }
        return best;
    }

    public static Vec3d eye(Entity e) {
        return new Vec3d(e.getX(), e.getEyeY(), e.getZ());
    }

    public static Vec3d body(Entity e) {
        return new Vec3d(e.getX(), e.getY() + e.getHeight() * 0.6, e.getZ());
    }

    public static void lookAt(ClientPlayerEntity p, Vec3d target) {
        Vec3d e = eye(p);
        double dx = target.x - e.x, dy = target.y - e.y, dz = target.z - e.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setPitch(MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, h)), -90f, 90f));
    }

    public static int findHotbar(ClientPlayerEntity p, Predicate<ItemStack> filter) {
        for (int i = 0; i < 9; i++) {
            if (filter.test(p.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    public static int selectedSlot(ClientPlayerEntity p) {
        return p.getInventory().getSelectedSlot();
    }

    public static void selectSlot(ClientPlayerEntity p, int slot) {
        if (slot >= 0 && slot < 9 && slot != selectedSlot(p)) p.getInventory().setSelectedSlot(slot);
    }

    public static void chat(MinecraftClient mc, String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§d[Archion]§r " + msg), false);
    }

    /** Conservative end-crystal damage upper bound (ignores armor, difficulty and block exposure). */
    public static double crystalDamage(Vec3d crystal, Entity e) {
        double dist = Math.sqrt(e.squaredDistanceTo(crystal.x, crystal.y, crystal.z)) / 12.0;
        if (dist > 1.0) return 0.0;
        double impact = 1.0 - dist;
        return (impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0;
    }
}
