package dev.archion.client;

import dev.archion.client.module.BaseFinder;
import dev.archion.client.module.Macros;
import dev.archion.client.module.Module;
import dev.archion.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ArchionScreen extends Screen {
    private static final int PURPLE = 0xFF9B72F2;
    private static final int PANEL = 0xEE17171F;
    private static final int TEXT = 0xFFF4F1FA;
    private static final int MUTED = 0xFFAAA6B8;

    private enum Tab {
        COMBAT("Combat"), EXPLORATION("Exploration"), MISC("Misc"), HUD("HUD");
        final String label;
        Tab(String label) { this.label = label; }
    }

    // HUD toggles are still settings-only placeholders (no in-game rendering yet)
    private static final Map<String, Boolean> HUD = new LinkedHashMap<>();
    static {
        HUD.put("Sword practice HUD", true);
        HUD.put("Mace timing HUD", true);
        HUD.put("Crystal inventory HUD", true);
        HUD.put("Armor durability HUD", true);
        HUD.put("Coordinates HUD", true);
    }

    private static Tab tab = Tab.COMBAT;
    private String status = "Ready · Right Shift to reopen";

    public ArchionScreen() {
        super(Text.literal("Archion Client"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 105;
        int bw = 142, bh = 20;

        int i = 0;
        for (Tab t : Tab.values()) {
            addDrawableChild(ButtonWidget.builder(Text.literal((t == tab ? "> " : "") + t.label), b -> {
                tab = t;
                status = t.label + " tab";
                clearAndInit();
            }).dimensions(left + 12, top + 43 + i * 24, bw, bh).build());
            i++;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(left + 12, top + 148, bw, bh).build());

        int x = left + 174;
        int[] row = { top + 43 };

        switch (tab) {
            case COMBAT -> ModuleManager.in(Module.Category.COMBAT).forEach(m -> moduleButton(m, x, row));
            case EXPLORATION -> {
                ModuleManager.in(Module.Category.EXPLORATION).forEach(m -> moduleButton(m, x, row));
                actionButton("Save waypoint", x, row, this::saveWaypoint);
                actionButton("Open waypoint file", x, row, () -> openFile(Waypoints.file(), "waypoint file"));
                actionButton("Reset found bases", x, row, () -> {
                    BaseFinder bf = ModuleManager.get(BaseFinder.class);
                    if (bf != null) bf.reset();
                    status = "Base finder cache cleared";
                });
            }
            case MISC -> {
                ModuleManager.in(Module.Category.MISC).forEach(m -> moduleButton(m, x, row));
                actionButton("Open macros file", x, row, () -> openFile(Macros.file(), "macros file"));
                actionButton("Reload macros", x, row, () -> {
                    Macros m = ModuleManager.get(Macros.class);
                    status = m == null ? "Macros unavailable" : "Loaded " + m.reload() + " macros";
                });
            }
            case HUD -> {
                for (String name : HUD.keySet().toArray(String[]::new)) {
                    addDrawableChild(ButtonWidget.builder(label(HUD.get(name), name), b -> {
                        HUD.put(name, !HUD.get(name));
                        b.setMessage(label(HUD.get(name), name));
                        status = name + (HUD.get(name) ? " enabled" : " disabled");
                    }).dimensions(x, row[0], 124, bh).build());
                    row[0] += 25;
                }
            }
        }
    }

    private void moduleButton(Module m, int x, int[] row) {
        addDrawableChild(ButtonWidget.builder(label(m.isEnabled(), m.name()), b -> {
            m.toggle();
            b.setMessage(label(m.isEnabled(), m.name()));
            status = m.name() + (m.isEnabled() ? " enabled" : " disabled") + " · " + m.description();
        }).dimensions(x, row[0], 124, 20).build());
        row[0] += 25;
    }

    private void actionButton(String text, int x, int[] row, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(text), b -> action.run())
                .dimensions(x, row[0], 124, 20).build());
        row[0] += 25;
    }

    private Text label(boolean on, String name) {
        return Text.literal((on ? "ON  " : "OFF ") + name);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 105;
        context.fill(left, top, left + 300, top + 210, PANEL);
        context.fill(left, top, left + 300, top + 3, PURPLE);
        context.fill(left + 12, top + 31, left + 288, top + 32, 0xFF393443);
        context.drawText(this.textRenderer, "ARCHION", left + 12, top + 10, TEXT, false);
        context.drawText(this.textRenderer, "CLIENT  /  1.21.11", left + 95, top + 12, PURPLE, false);
        context.drawText(this.textRenderer, tab.label.toUpperCase(), left + 174, top + 33, MUTED, false);
        context.drawText(this.textRenderer, trimStatus(), left + 12, top + 188, MUTED, false);
        super.render(context, mouseX, mouseY, delta);
    }

    private String trimStatus() {
        return status.length() > 46 ? status.substring(0, 43) + "..." : status;
    }

    private void saveWaypoint() {
        var client = ArchionClient.client();
        if (client.player == null || client.world == null) {
            status = "Join a world before saving a waypoint";
            return;
        }
        boolean ok = Waypoints.add(client, "Manual", client.player.getX(), client.player.getY(), client.player.getZ());
        status = ok ? "Waypoint saved to config/archion/waypoints.txt" : "Could not save waypoint";
    }

    private void openFile(Path file, String what) {
        try {
            Files.createDirectories(file.getParent());
            if (!Files.exists(file)) Files.createFile(file);
            Util.getOperatingSystem().open(file.toFile());
            status = "Opened " + what;
        } catch (IOException e) {
            status = "Could not open " + what;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
