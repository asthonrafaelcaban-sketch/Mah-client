package dev.archion.client;

import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class Waypoints {
    private Waypoints() {}

    public static Path file() {
        return Config.dir().resolve("waypoints.txt");
    }

    public static boolean add(MinecraftClient mc, String label, double x, double y, double z) {
        if (mc.world == null) return false;
        String line = String.format("%s | %s | %s | X %.1f Y %.1f Z %.1f%n",
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                mc.world.getRegistryKey().getValue(), label, x, y, z);
        try {
            Files.createDirectories(file().getParent());
            Files.writeString(file(), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
