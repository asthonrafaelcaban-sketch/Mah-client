package dev.archion.client;

import dev.archion.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ArchionClient implements ClientModInitializer {
    public static final String MOD_ID = "archion";
    public static final Logger LOGGER = LoggerFactory.getLogger("Archion");
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        Config.load();
        ModuleManager.init();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.archion.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ArchionScreen());
                }
            }
            ModuleManager.tick(client);
        });
    }

    public static MinecraftClient client() {
        return MinecraftClient.getInstance();
    }
}
