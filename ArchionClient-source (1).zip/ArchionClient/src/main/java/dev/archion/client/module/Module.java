package dev.archion.client.module;

import dev.archion.client.Config;
import net.minecraft.client.MinecraftClient;

import java.util.Locale;

public abstract class Module {
    public enum Category {
        COMBAT("Combat"), EXPLORATION("Exploration"), MISC("Misc");
        public final String label;
        Category(String label) { this.label = label; }
    }

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;

    protected Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.enabled = Config.getBool("module." + key() + ".enabled", false);
    }

    public final String key() { return name.toLowerCase(Locale.ROOT).replace(" ", ""); }
    public final String name() { return name; }
    public final String description() { return description; }
    public final Category category() { return category; }
    public final boolean isEnabled() { return enabled; }

    public final void toggle() {
        enabled = !enabled;
        Config.setBool("module." + key() + ".enabled", enabled);
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}

    /** Called every client tick while enabled and in a world. */
    public abstract void onTick(MinecraftClient mc);
}
