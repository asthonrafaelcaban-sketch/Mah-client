package dev.archion.client.module;

import dev.archion.client.Config;
import dev.archion.client.PlayerUtil;
import dev.archion.client.Waypoints;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Scans chunks the server has already sent you for player-built signs: storage blocks,
 * redstone parts, glass, etc. Reports hits in chat and saves them to waypoints.txt.
 * Only reads data your client already has; nothing is requested from the server.
 */
public final class BaseFinder extends Module {
    private static final Set<Block> BUILT = Set.of(
            Blocks.ENDER_CHEST, Blocks.HOPPER, Blocks.OBSERVER, Blocks.PISTON, Blocks.STICKY_PISTON,
            Blocks.BEACON, Blocks.REDSTONE_LAMP, Blocks.NOTE_BLOCK, Blocks.REPEATER, Blocks.COMPARATOR,
            Blocks.GLASS, Blocks.TINTED_GLASS, Blocks.ENCHANTING_TABLE);

    private final int threshold = Config.getInt("basefinder.threshold", 6);
    private final boolean requireBuilt = Config.getBool("basefinder.requireBuiltBlocks", true);
    private final int chunksPerTick = Math.max(1, Config.getInt("basefinder.chunksPerTick", 8));
    private final int mergeRadius = Config.getInt("basefinder.mergeRadiusChunks", 3);

    private final Set<Long> scanned = new HashSet<>();
    private final List<ChunkPos> reported = new ArrayList<>();
    private ClientWorld lastWorld;
    private int found;

    public BaseFinder() {
        super("Base Finder", Category.EXPLORATION, "Flags loaded chunks that look player-built");
    }

    public void reset() {
        scanned.clear();
        reported.clear();
        found = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientWorld w = mc.world;
        if (w != lastWorld) { reset(); lastWorld = w; }

        int rd = mc.options.getViewDistance().getValue();
        ChunkPos me = mc.player.getChunkPos();
        int budget = chunksPerTick;

        for (int dx = -rd; dx <= rd && budget > 0; dx++) {
            for (int dz = -rd; dz <= rd && budget > 0; dz++) {
                int cx = me.x + dx, cz = me.z + dz;
                long key = ChunkPos.toLong(cx, cz);
                if (scanned.contains(key)) continue;
                WorldChunk chunk = w.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                scanned.add(key);
                budget--;
                scan(mc, chunk, cx, cz);
            }
        }
    }

    private void scan(MinecraftClient mc, WorldChunk chunk, int cx, int cz) {
        int storage = 0, utility = 0, built = 0, sampleY = 64;
        for (BlockPos bp : chunk.getBlockEntityPositions()) {
            BlockState s = chunk.getBlockState(bp);
            if (isStorage(s)) { storage++; sampleY = bp.getY(); }
            else if (s.isOf(Blocks.FURNACE) || s.isOf(Blocks.BLAST_FURNACE) || s.isOf(Blocks.SMOKER)
                    || s.isOf(Blocks.BREWING_STAND)) utility++;
        }
        for (ChunkSection sec : chunk.getSectionArray()) {
            if (!sec.isEmpty() && sec.hasAny(st -> BUILT.contains(st.getBlock()) || st.getBlock() instanceof ShulkerBoxBlock)) built++;
        }

        int score = storage * 2 + utility + built;
        if (score < threshold || (requireBuilt && built == 0)) return;

        for (ChunkPos r : reported) {
            if (Math.abs(r.x - cx) <= mergeRadius && Math.abs(r.z - cz) <= mergeRadius) return;
        }
        reported.add(new ChunkPos(cx, cz));
        found++;

        double x = cx * 16 + 8, z = cz * 16 + 8;
        String label = "Base? score " + score + " (storage " + storage + ")";
        Waypoints.add(mc, label, x, sampleY, z);
        PlayerUtil.chat(mc, String.format("Possible base near X %.0f Y %d Z %.0f · %s · #%d", x, sampleY, z, label, found));
    }

    private static boolean isStorage(BlockState s) {
        Block b = s.getBlock();
        return b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL
                || b == Blocks.ENDER_CHEST || b == Blocks.HOPPER || b == Blocks.DISPENSER
                || b == Blocks.DROPPER || b instanceof ShulkerBoxBlock;
    }
}
