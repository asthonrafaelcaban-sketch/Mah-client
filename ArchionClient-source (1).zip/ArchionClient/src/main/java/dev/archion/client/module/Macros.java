package dev.archion.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import dev.archion.client.Config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

/**
 * Key-bound chat/command macros loaded from config/archion/macros.txt.
 * Format: KEY | action ;; action ;; wait 20 ;; action
 * Actions starting with / are commands, everything else is sent as chat. "wait N" pauses N ticks.
 */
public final class Macros extends Module {
    private static final class Macro {
        final String keyName;
        final int code;
        final List<String> actions;
        boolean down;

        Macro(String keyName, int code, List<String> actions) {
            this.keyName = keyName;
            this.code = code;
            this.actions = actions;
        }
    }

    private static final String SAMPLE = """
            # Archion macros. One per line:  KEY | action ;; action ;; wait 20 ;; action
            # KEY uses Minecraft key names without the prefix: g, h, f6, keypad.1, left.bracket ...
            # Actions starting with / are commands, anything else is sent as chat.
            # Examples (remove the leading # to enable):
            # g | /sethome base
            # h | /home base
            # j | /kill ;; wait 40 ;; /home base
            """;

    private final int maxPerTick = Math.max(1, Config.getInt("macros.maxActionsPerTick", 1));
    private final List<Macro> macros = new ArrayList<>();
    private final Deque<String> queue = new ArrayDeque<>();
    private int wait;

    public Macros() {
        super("Macros", Category.MISC, "Key-bound chat/command macros");
        reload();
    }

    public static Path file() {
        return Config.dir().resolve("macros.txt");
    }

    public int reload() {
        macros.clear();
        Path f = file();
        try {
            Files.createDirectories(f.getParent());
            if (!Files.exists(f)) Files.writeString(f, SAMPLE, StandardCharsets.UTF_8);
            for (String raw : Files.readAllLines(f, StandardCharsets.UTF_8)) {
                String line = raw.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                int bar = line.indexOf('|');
                if (bar < 1) continue;
                String keyName = line.substring(0, bar).trim().toLowerCase(Locale.ROOT);
                List<String> actions = new ArrayList<>();
                for (String a : line.substring(bar + 1).split(";;")) {
                    if (!a.isBlank()) actions.add(a.trim());
                }
                try {
                    int code = InputUtil.fromTranslationKey("key.keyboard." + keyName).getCode();
                    if (!actions.isEmpty()) macros.add(new Macro(keyName, code, actions));
                } catch (IllegalArgumentException ignored) {
                    // unknown key name, skip line
                }
            }
        } catch (IOException ignored) {}
        return macros.size();
    }

    @Override
    protected void onDisable() {
        queue.clear();
        wait = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (wait > 0) {
            wait--;
        } else {
            int sent = 0;
            while (!queue.isEmpty() && sent < maxPerTick) {
                String a = queue.poll();
                if (a.toLowerCase(Locale.ROOT).startsWith("wait ")) {
                    try { wait = Integer.parseInt(a.substring(5).trim()); } catch (NumberFormatException ignored) {}
                    break;
                }
                if (a.startsWith("/")) mc.player.networkHandler.sendChatCommand(a.substring(1));
                else mc.player.networkHandler.sendChatMessage(a);
                sent++;
            }
        }

        long window = mc.getWindow().getHandle();
        for (Macro m : macros) {
            boolean pressed = mc.currentScreen == null && GLFW.glfwGetKey(window, m.code) == GLFW.GLFW_PRESS;
            if (pressed && !m.down) queue.addAll(m.actions);
            m.down = pressed;
        }
    }
}
