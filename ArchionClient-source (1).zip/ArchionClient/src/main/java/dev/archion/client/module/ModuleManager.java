package dev.archion.client.module;

import dev.archion.client.ArchionClient;
import dev.archion.client.Config;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.add(new SwordPvP());
        MODULES.add(new MacePvP());
        MODULES.add(new CrystalPvP());
        MODULES.add(new BaseFinder());
        MODULES.add(new Macros());
        Config.save(); // writes any defaults that were registered
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> in(Module.Category c) {
        return MODULES.stream().filter(m -> m.category() == c).toList();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            try {
                m.onTick(mc);
            } catch (Exception e) {
                ArchionClient.LOGGER.error("Module {} crashed, disabling it", m.name(), e);
                m.toggle();
            }
        }
    }
}
